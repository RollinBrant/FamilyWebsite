---
date: 15-10-24
description: "10-24-15 Favor from May"

featured_image: "/letters/1915/10-24-15 Favor from May/Scan_20170112(2).jpg"

title: "10-24-15 Favor from May"
---

{{< gallery dir="/letters/1915/10-24-15 Favor from May" />}}
