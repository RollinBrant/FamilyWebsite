---
date: 15-11-13
description: "11-13-15 Mad at Mama"

featured_image: "/letters/1915/11-13-15 Mad at Mama/Scan_20170112(0).jpg"

title: "11-13-15 Mad at Mama"
---

{{< gallery dir="/letters/1915/11-13-15 Mad at Mama" />}}
