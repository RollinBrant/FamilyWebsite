---
date: 15-11-07
description: "11-7-15 Please Send Cake"

featured_image: "/letters/1915/11-7-15 Please Send Cake/Scan_20170112(2).jpg"

title: "11-7-15 Please Send Cake"
---

{{< gallery dir="/letters/1915/11-7-15 Please Send Cake" />}}
