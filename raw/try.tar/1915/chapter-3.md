---
date: 15-10-02
description: "10-2-15 On Board the Corsican"

featured_image: "/letters/1915/10-2-15 On Board the Corsican/Scan_20170108(04).jpg"

title: "10-2-15 On Board the Corsican"
---

{{< gallery dir="/letters/1915/10-2-15 On Board the Corsican" />}}
