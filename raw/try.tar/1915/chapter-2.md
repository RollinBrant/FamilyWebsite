---
date: 15-10-19
description: "10-19-15 Trip to London"

title: "10-19-15 Trip to London"
---

{{< gallery dir="/letters/1915/10-19-15 Trip to London" />}}
<!---
 {{< load-photoswipe >}}
--> 

